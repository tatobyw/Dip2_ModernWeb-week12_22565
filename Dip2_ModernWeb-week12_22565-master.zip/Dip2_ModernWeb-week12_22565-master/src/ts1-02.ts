let counter:number = 100 //inferred type
let stdName: string = 'Mark' //explicit type
let isActivate: boolean = true //explicit type
const numberList: number[] = [10, 20, 30] //explicit type

