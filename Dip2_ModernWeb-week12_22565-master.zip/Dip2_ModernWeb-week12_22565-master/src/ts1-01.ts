const msg:string = "Hello"
const fname:string = "Mark Zuckerberg"
const province:string = "Trat"

// console.log(msg + '  ' + fname)
console.log(`${msg} ${fname}`)
console.log(province)